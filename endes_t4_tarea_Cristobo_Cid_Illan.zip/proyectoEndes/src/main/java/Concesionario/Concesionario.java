package Concesionario;

import java.util.ArrayList;
import Auto.Auto;
/**
 * Clase Concesionario.Concesionario
 * Representa un concesionario de automóviles que gestiona una colección de objetos Auto.Auto.
 *
 * @author Illan/Tunivers
 * @version 1.0, 2024/02/14
 */
public class Concesionario {

    private ArrayList<Auto> autos;  // ArrayList para almacenar objetos Auto.Auto

    /**
     * Constructor que inicializa la lista de autos.
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Agrega un objeto Auto.Auto a la colección del concesionario.
     *
     * @param auto El objeto Auto.Auto que se agregará al concesionario.
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Obtiene una lista de todos los autos en la colección del concesionario.
     *
     * @return Una lista de todos los objetos Auto.Auto en la colección.
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Imprime los detalles de cada auto en la colección del concesionario.
     */
    public void imprimirAutos() {
        for (Auto auto : autos) {
            System.out.println(auto);
        }
    }
}

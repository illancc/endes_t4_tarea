package Auto;
import Concesionario.Concesionario;
/**
 * Clase Auto.Auto
 * Representa un automóvil con atributos para la marca y el modelo.
 *
 * @author Illan/tunivers
 * @version 1.0, 2024/02/14
 */

public class Auto {

    private String marca;   // Marca del automóvil
    private String modelo;  // Modelo del automóvil

    /**
     * Constructor para inicializar un objeto Auto.Auto con la marca y modelo especificados.
     *
     * @param marca La marca del automóvil.
     * @param modelo El modelo del automóvil.
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Obtiene la marca del automóvil.
     *
     * @return La marca del automóvil.
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Establece la marca del automóvil.
     *
     * @param marca La nueva marca del automóvil.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Obtiene el modelo del automóvil.
     *
     * @return El modelo del automóvil.
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Establece el modelo del automóvil.
     *
     * @param modelo El nuevo modelo del automóvil.
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Sobrescribe el método toString para proporcionar una representación de cadena del objeto Auto.Auto.
     *
     * @return Una representación de cadena del objeto Auto.Auto.
     */
    @Override
    public String toString() {
        return "Auto.Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}